-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-10-2021 a las 11:46:59
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `variabilidad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(200) NOT NULL AUTO_INCREMENT,
  `id_imagen` int(11) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `permisos` varchar(200) DEFAULT NULL,
  `fechaCaptura` varchar(200) DEFAULT NULL,
  `usuarioregistra` varchar(200) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `id_imagen`, `nombre`, `apellido`, `email`, `password`, `permisos`, `fechaCaptura`, `usuarioregistra`, `estado`, `user`) VALUES
(1, 35, 'SMALL', 'SMALL', 'SMALL@gmail.com', '011c945f30ce2cbafc452f39840f025693339c42', 'LIM', '12/02/2021', 'small@personeriamedellin.gov.co', 1, 'small'),
(2, 35, 'MIDDLE', 'MIDDLE', 'MIDDLE@gmail.com', '011c945f30ce2cbafc452f39840f025693339c42', 'ADMIN', '12/02/2021', 'middle@personeriamedellin.gov.co', 1, 'middle'),
(3, 35, 'FULL', 'FULL', 'FULL@gmail.com', '011c945f30ce2cbafc452f39840f025693339c42', 'SUPER', '12/02/2021', 'emoreno@personeriamedellin.gov.co', 1, 'full');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
