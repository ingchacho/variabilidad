<?php 	
	require_once "controlador/Conexion.php";
	$obj= new conectar();
	$conexion=$obj->conexion();
	$sql="select * from usuarios where permisos='admin'";
	$result=mysqli_query($conexion,$sql);
	$validar=0;
	if(mysqli_num_rows($result) > 0){
		$validar=1;
	}
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	
		<title>Login de usuario</title>
		<link rel="stylesheet" href="css/estiloslogin.css">
        <link href="http://netdna.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.css" rel="stylesheet">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
        <link href="assets/css/gsdk-bootstrap-wizard.css" rel="stylesheet" />
        <link href="assets/css/demo.css" rel="stylesheet" />
        <script src="librerias/jquery-3.2.1.min.js"></script>
		<script src="vista/js/funciones.js"></script>
        <style type="text/css">
		video{
			position: fixed;
			min-width: 100%;
			min-height: 100%;
			top: 50%;
			left: 50%;
			transform: translateX(-50%) translateY(-50%); 
			z-index: -1;
		}
	</style>
	</head>
	<body>
    <video src="modelo/4.mp4" autoplay loop muted></video>
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">
                    <div class="wizard-container">
                        <div class="card wizard-card" data-color="orange" id="wizardProfile">
                            <form id="frmLogin">
                                    <div class="wizard-header">
                        	            <h3>
                                            <b>SPL Soft - Presentaciones</b><br>
                        	            </h3>
                                	</div>
                                    <div class="wizard-navigation">
                                        <ul>
                                            <li><a href="#about" data-toggle="tab">Login Users</a></li>
                                        </ul>
            						</div>
                                    <div class="tab-content">
                                        <div class="tab-pane" id="about">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>Usuario <small>(*):</small></label>
                                                        <input class="form-control" type="email" name="usuario" id="usuario" required>
                                                    </div>
                                                    <div class="grupo">			
                                                        <label>Password <small>(*)</small></label>    
                                                        <input class="form-control" type="password" name="password" id="password" required>
                                                    </div>
                                                    </br>
                                                    <div class="wizard-footer height-wizard">
                                                        <div class="pull-right">
                                                            <button  class='btn btn-fill btn-warning btn-wd btn-sm'  id="entrarSistema">Iniciar sesi&oacute;n</button>
                                                            <?php  if(!$validar): ?>
                                                            <a href="registro.php" class="btn btn-danger btn-sm"><b>Registrar usuario administrador</b></a>
                                                            <?php endif; ?>
                                                            <br/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </form>	
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </body>
	<script src="assets/js/jquery-2.2.4.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-bootstrap-wizard.js"></script>
	<script src="assets/js/jquery.validate.min.js"></script>
</html>

<script type="text/javascript">
	$(document).ready(function(){
		$('#entrarSistema').click(function(){
			vacios=validarFormVacio('frmLogin');
			if(vacios > 0){
				alert("Debe llenar todos los campos!!");
				return false;
			}

		datos=$('#frmLogin').serialize();
		$.ajax({
			type:"POST",
			data:datos,
			url:"controlador/login.php",
			success:function(r){
				if(r==1){
					window.location="vista/inicio.php";
				}else{
					alert("usuario o clave incorrecto");
				}
			}
		});
	});
	});
</script>