<?php 
	session_start();
	require_once "Conexion.php";
	require_once "Usuarios.php";
	$obj= new usuarios();
	$datos=array(
		$_POST['usuario'],
		$_POST['password']
	);	
	echo $obj->loginUser($datos);		
 ?>