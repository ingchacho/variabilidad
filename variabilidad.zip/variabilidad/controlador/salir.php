<?php 
	session_start();
	session_destroy();

	echo"<script>
			alert('Sesion finalizada con exito. Muchas gracias'); 
		</script>";
	header("location:../index.php");
 ?>