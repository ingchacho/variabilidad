<?php 
	session_start();
	$idusuario=$_SESSION['iduser'];
	
	$usuariosesion=$_SESSION['usuario'];

	require_once "Conexion.php";
	require_once "Usuarios.php";
	$fecha=date("d/m/Y");
	//traemos los datos del usuario por el post
	$nombre=$_POST['nombre'];
	$apellido=$_POST['apellido'];
	$usuario= $_POST['usuario'];		
	$pass=sha1($_POST['password']);
	$permisos= $_POST['permisosSelect'];											
				
	$obj= new usuarios();		
	$datos=array();
	$nombreImg=$_FILES['imagen']['name'];
	$rutaAlmacenamiento=$_FILES['imagen']['tmp_name'];
	$carpeta='../archivos/';
	$rutaFinal=$carpeta.$nombreImg;		
	
	$datosImg=array( //ojo estos datos van para el insert de la tabla imagenesusuario
		$_POST['usuario'],
		$nombreImg,
		$rutaFinal		
					);							
	if(move_uploaded_file($rutaAlmacenamiento, $rutaFinal)){
				 $idimagen=$obj->agregaImagen($datosImg);
				  if($idimagen > 0){			//ojo estos datos van para el insert de la tabla usuario		
						$datos[0]=$idimagen;
						$datos[1]=$nombre;
						$datos[2]=$apellido;
						$datos[3]=$usuario;						
						$datos[4]=$pass;			
						$datos[5]=$permisos;				
						$datos[6]=$usuariosesion;				
						echo $obj->registroUsuario($datos);
				}else{
					echo 0;
				}
		}					

 ?>