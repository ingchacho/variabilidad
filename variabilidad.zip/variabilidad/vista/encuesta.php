<?php 
	session_start();
	if(isset($_SESSION['usuario'])){		    
        require_once "../controlador/Conexion.php";
        $obj= new conectar();
        $mysqli= $obj->conexion();
 ?>
<!DOCTYPE html>
<html lang="pt-br">  
    <head>      
        <meta charset="UTF-8">      
        <meta name="viewport" content="width=device-width, initial-scale=1.0">      
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Encuesta</title>
        <link rel="shortcut icon" href="../imagenes/favicon.ico" />
        <link rel="stylesheet" href="css/estilosinicio.css">
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
        <link href="../assets/css/gsdk-bootstrap-wizard.css" rel="stylesheet" />
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="js/menu.js"></script>
        <script src="../librerias/sweetalert.min.js"></script>
        <style type="text/css">
            video{
                position: fixed;
                min-width: 100%;
                min-height: 100%;
                top: 50%;
                left: 50%;
                transform: translateX(-50%) translateY(-50%); 
                z-index: -1;
            }
        </style>
    </head>
    <body>      
        <?php require_once "menu.php"; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        <video src="../modelo/4.mp4" autoplay loop muted></video>
            <div class="row" style="width:80%; margin:auto;">
                <div class="col-sm-8 col-sm-offset-2">
                    <div class="wizard-container"  style="width:90%;padding:10px;">
                        <div class="card wizard-card" data-color="orange" id="wizardProfile" >
                            <form  id="frmcliente" method="POST" action="" enctype="multipart/form-data">
                                <div class="wizard-header">
                                    <h3>Encuesta</h3>
                                </div>
                                <br/>
                                <br/>
                                <div class="wizard-navigation">
                                    <ul>
                                        <li><a href="#encuesta" data-toggle="tab"></a></li>
                                    </ul>
                                </div>
                                <div class="tab-content">
                                    <div class="tab-pane" id="encuesta">
                                        <h4 class="info-text"> Bienvenido a tu configuraci&oacute;n de Encuesta</h4>
                                        <div class="row">

                                            <div class="col-sm-8">
                                                <textarea cols="20" rows="10" class="form-control"></textarea>
                                            </div>                
            
                                            <div class="col-sm-3">
                                                <div class="form-group">
                                                    <label>Pregunta<small>(*):</small></label><br>
                                                    <input type="text" id="pregunta" name="pregunta" class="form-control"/>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Opci&oacute;n 1 <small>:</small></label>
                                                    <input name="opcion" id="opcion" type="radio" class="form-control">
                                                    <label>Opci&oacute;n 2 <small>:</small></label>
                                                    <input name="opcion" id="opcion" type="radio" class="form-control">
                                                    <label>Opci&oacute;n 3 <small>:</small></label>
                                                    <input name="opcion" id="opcion" type="radio" class="form-control">                                            
                                                    <button type="submit" name="" class="btn btn-primary">Agregar otra opci&oacute;n</button>
                                                </div>
                                                <h3>Otros</h3>
                                                <div class="form-group">
                                                    <label>Permitir env&iacute;os<small>(*):</small></label>
                                                    <input name="envios" id="envios" type="checkbox" class="form-control">
                                                </div>
                                                
                                                <h3>Mostrar resultados</h3>
                                                <div class="form-group">
                                                    <label>Gr&aacute;fico de barras <small>:</small></label>
                                                    <input name="resultados" id="resultados" type="radio" class="form-control">
                                                    <label>Gr&aacute;fico de pastel <small>:</small></label>
                                                    <input name="resultados" id="resultados" type="radio" class="form-control">
                                                </div>                                        
                                            </div>

                                        </div>                
                                    </div>                
                                </div>                                
                                <div class="wizard-footer height-wizard">
                                    <div class="pull-right">
                                        <input type='button' class='btn btn-next btn-fill btn-warning btn-wd btn-sm' name='next' value='Next' />
                                        <input type='button' class='btn btn-finish btn-fill btn-warning btn-wd btn-sm' name='enviar' id='enviar' value='Enviar' />
                                    </div>

                                    <div class="pull-left">
                                        <input type='button' class='btn btn-previous btn-fill btn-default btn-wd btn-sm' name='previous' value='Previous' />
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </form>
                        </div>
                    </div> <!--   wizar   -->
                </div> <!--   cols   -->
            </div><!--   rows   -->
    </body>
    	<!--   Core JS Files   -->
	<script src="../assets/js/jquery-2.2.4.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>

	<!--  Plugin for the Wizard -->
	<script src="../assets/js/gsdk-bootstrap-wizard.js"></script>

	<!--  More information about jquery.validate here: http://jqueryvalidation.org/	 -->
	<script src="../assets/js/jquery.validate.min.js"></script>
</html>
<?php 
	}else{
		header("location:./index.php");
	}
 ?>