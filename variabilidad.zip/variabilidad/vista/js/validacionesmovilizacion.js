$.validator.addMethod('exp', function(value, element, param) 
{
  return this.optional(element) || value.match(param);
},'Solo acepta letras y espacios en blanco');

$("#frmmovilizacion").validate({
    rules:{
        tipomanifestacion:{
            required: true
        },
        descripcionmovilizacion:{
            required: true,
            minlength: 5,
            maxlength: 100,
            exp: /^[a-zA-ZÀ-ÿ\s]{1,40}$/ // Letras y espacios, pueden llevar acentos.
            //regexp: /^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ]+$/ /*Se escribe la expresión que vamos a usar*/
        },
        dia:{
            required: true
        },
         mes:{
            required: true          
        },
        ano:{
            required: true
        },
        sitioinicio:{
            required: true,
            minlength: 5,
            maxlength: 30,
            exp: /^[a-zA-ZÀ-ÿ\s]{1,40}$/ // Letras y espacios, pueden llevar acentos.
            //regexp: /^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ]+$/ /*Se escribe la expresión que vamos a usar*/
        },

        sitiofinal:{
            required: true,
            minlength: 5,
            maxlength: 30,
            exp: /^[a-zA-ZÀ-ÿ\s]{1,40}$/ // Letras y espacios, pueden llevar acentos.
            //regexp: /^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ]+$/ /*Se escribe la expresión que vamos a usar*/
        },
        horainicio:{
            required: true
        },
        horafinal:{
            required: true          
        },

        recorrido:{
            required: true,
            minlength: 20,
            maxlength: 200,
            exp: /^[a-zA-ZÀ-ÿ\s]{1,40}$/ // Letras y espacios, pueden llevar acentos.
            //regexp: /^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ]+$/ /*Se escribe la expresión que vamos a usar*/
        },

        cantidadparticipantes:{
            required: true,
            minlength: 1,
            maxlength: 10,
            digits:true,
            exp:/^[0-9]$/
        }
    }
})



$("#enviar").click(function(){
    if ($("#frmmovilizacion").valid()==false) {
        return;
    } else {
        let tipomanifestacion = $("#tipomanifestacion").val()
        let descripcionmovilizacion = $("#descripcionmovilizacion").val()
        let dia = $("#dia").val()
        let mes = $("#mes").val()      
        let ano = $("#ano").val()      
        let sitioinicio = $("#sitioinicio").val()      
        let sitiofinal = $("#sitiofinal").val()      
        let horainicio = $("#horainicio").val()      
        let horafinal = $("#horafinal").val()      
        let recorrido = $("#recorrido").val()      
        let cantidadparticipantes = $("#cantidadparticipantes").val()      
    }
});


