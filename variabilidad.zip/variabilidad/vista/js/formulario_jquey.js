$.validator.addMethod('exp', function(value, element, param) 
{
  return this.optional(element) || value.match(param);
},'Solo acepta letras y espacios en blanco');

$("#frmregistro").validate({
    rules:{        
        nivelacademico:{
            required: true,        
        },
        profesion:{
            required: true,        
        },
        entidadcontratante:{
            required: true,               
        },
        entidadaseguradora:{
            required: true          
        },
        nivelriesgo:{
            required: true,           
        }
    }
})





$("#enviar").click(function(){

    if($("#frmregistro").valid()==false){
        return;
    }
    else
    {
    let nivelacademico = $("#nivelacademico").val()
    let profesion = $("#profesion").val()
    let entidadcontratante = $("#entidadcontratante").val()
    let entidadaseguradora = $("#entidadaseguradora").val()
    let nivelriesgo = $("#nivelriesgo").val()  
    }

});


