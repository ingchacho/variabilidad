<?php 
  require_once "../controlador/Conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();	
  $usuario = $_SESSION['usuario']."@gmail.com";	  
	$sql="SELECT * FROM usuarios WHERE email = '$usuario'";				
	$result=mysqli_query($conexion,$sql);
  while($fila=mysqli_fetch_array($result)){    
    $permisos=$fila["permisos"];
    $nombre=$fila["nombre"];
  }
  
 ?>
  <nav>              
    <div class="menu-icon">                      
      <i class="fa fa-bars fa-2x"></i>            
    </div>                
    <div class="logo">
      <a href="inicio.php">
        <img src="../imagenes/5ok.jpg" width="100%" alt="">
      </a>
    </div>                  
    <div class="menu">                  
      <ul>  
        <?php                      
          if($permisos=="SUPER"):                     
        ?>
        <li><a href="preguntasrespuestas.php">Preguntas y respuestas</a></li>                                                                                 
        <li><a href="nubepalabras.php">Nube de palabras</a></li>                                                                                
        <li><a href="encuesta.php">Ecuentas</a></li>                                                                                          
        <li>                                                          
            <b><?php echo $_SESSION['usuario']; ?></b>
        </li>        
        <li> 
          <a style="color:red" href="../controlador/salir.php">
            Cerrar sesi&oacute;n
          </a>
        </li>                                
        
        <?php 
          endif;
        ?>

        <?php                      
            if($permisos=="ADMIN"):	                    
        ?>
        <li><a href="nubepalabras.php">Nube de palabras</a></li>                                                                                
        <li><a href="encuesta.php">Ecuentas</a></li>                                                                                          
        <li>                                                         
            <b><?php echo $_SESSION['usuario']; ?></b>
        </li>        
        <li> 
          <a style="color:red" href="../controlador/salir.php">
            Cerrar sesi&oacute;n
          </a>
        </li>                                

        <?php 
          endif;
        ?>

        <?php                      
          if($permisos=="LIM"):                     
        ?>
        <li><a href="encuesta.php">Ecuentas</a></li>                                                                                
        <li>                                                         
            <b><?php echo $_SESSION['usuario']; ?></b>
          </li>        
        <li> 
          <a style="color:red" href="../controlador/salir.php">
            Cerrar sesi&oacute;n
          </a>
        </li>                                
        <?php 
          endif;
        ?> 

      </ul>                
    </div>        
  </nav>          
