<?php 
	session_start();
	if(isset($_SESSION['usuario'])){		
 ?>

<!DOCTYPE html>
<html lang="pt-br">  
  <head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Diseño l&iacute;nea de productos</title>
    <link rel="shortcut icon" href="../imagenes/favicon.ico" />
    <link rel="stylesheet" href="css/estilosinicio.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="js/menu.js"></script>
    <?php require_once "menu.php"; ?>
    <style type="text/css">
		video{
			position: fixed;
			min-width: 100%;
			min-height: 100%;
			top: 50%;
			left: 50%;
			transform: translateX(-50%) translateY(-50%); 
			z-index: -1;
		}
	</style>

  </head>
  <body>      
    <video src="../modelo/4.mp4" autoplay loop muted></video>
    <header>              

    </header>           
  </body>
</html>
<?php 
	}else{
		//header("location:./index.php");
	}
 ?>